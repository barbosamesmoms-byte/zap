package br.com.brasaxpress.alarme

import android.app.Notification
import android.app.Person
import android.content.ComponentName
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class WaListener : NotificationListenerService() {
    companion object {
        /** true enquanto o Android mantém este serviço conectado. */
        @Volatile var conectado = false
        private var ultimaChave = ""
        private var ultimaHora = 0L
    }

    private fun hora(): String = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())

    private fun diagnostic(message: String) = Diag.add(this, message)

    override fun onListenerConnected() {
        super.onListenerConnected()
        conectado = true
        getSharedPreferences("alarme_debug", MODE_PRIVATE).edit().putString("listener", "conectado").apply()
        diagnostic("Acesso às notificações conectado")
    }

    override fun onListenerDisconnected() {
        conectado = false
        getSharedPreferences("alarme_debug", MODE_PRIVATE).edit().putString("listener", "desconectado").apply()
        diagnostic("Android desconectou o acesso às notificações")
        // Pede ao Android para reconectar sozinho
        try { requestRebind(ComponentName(this, WaListener::class.java)) } catch (_: Exception) {}
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val n = sbn.notification
        val e = n.extras
        val pkg = sbn.packageName

        // Teste de entrega feito pelo próprio app (vigia): só registra que o Android entregou
        if (pkg == packageName && sbn.id == Watchdog.HB_ID) {
            Watchdog.ultimoBatimento = System.currentTimeMillis()
            return
        }

        // Marca que o Android continua entregando notificações (aparece no Diagnóstico)
        getSharedPreferences("alarme_debug", MODE_PRIVATE).edit()
            .putString("visto", SimpleDateFormat("dd/MM HH:mm:ss", Locale.getDefault()).format(Date()) + " · " + pkg)
            .apply()

        // Só registra e trata apps que têm regra ligada
        val candidatas = Store.rules(this).filter { it.enabled && it.pkg == pkg }
        if (candidatas.isEmpty()) return

        val titulo = e.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val texto = (e.getCharSequence(Notification.EXTRA_TEXT) ?: e.getCharSequence(Notification.EXTRA_BIG_TEXT))
            ?.toString().orEmpty()

        val isGroup = e.getBoolean("android.isGroupConversation", false) ||
            e.getCharSequence("android.conversationTitle") != null
        val resumo = n.flags and Notification.FLAG_GROUP_SUMMARY != 0
        val fixa = n.flags and (Notification.FLAG_ONGOING_EVENT or Notification.FLAG_FOREGROUND_SERVICE) != 0
        val desc = (if (isGroup) "grupo" else "individual") +
            (if (resumo) " resumo" else "") + (if (fixa) " fixa" else "") + " cat=" + (n.category ?: "-")

        if (resumo) {
            diagnostic("Ignorada: resumo [$desc]")
            return
        }
        if (n.category == Notification.CATEGORY_CALL) {
            diagnostic("Ignorada: chamada [$desc]")
            return
        }
        // "WhatsApp procurando novas mensagens" e similares não são mensagens
        if (Rules.isWhatsApp(pkg) && Rules.isSync(n, titulo, texto)) {
            diagnostic("Ignorada: aviso fixo/sincronização [$desc] \"${("$titulo $texto").take(40)}\"")
            return
        }

        val agora = Calendar.getInstance()
        val r = candidatas
            .filter { Rules.active(it, agora) && Rules.typeOk(it, isGroup) }
            .maxByOrNull { it.volume }
        if (r == null) {
            val dentro = candidatas.any { Rules.active(it, agora) }
            diagnostic(if (!dentro) "Ignorada: fora do dia/horário da regra [$desc]" else "Ignorada: tipo da regra não combina [$desc]")
            return
        }

        // O WhatsApp às vezes reposta a mesma notificação; não toca de novo para a mesma mensagem
        val chave = "${sbn.key}|$texto"
        val agoraMs = System.currentTimeMillis()
        if (chave == ultimaChave && agoraMs - ultimaHora < 20 * 1000L) {
            diagnostic("Ignorada: mesma mensagem repetida [$desc]")
            return
        }
        ultimaChave = chave
        ultimaHora = agoraMs

        val quem = titulo.ifEmpty { r.label }
        diagnostic(if (AlarmPlayer.active) "Alarme já estava tocando [$desc]" else "TOCOU o alarme [$desc]")
        AlarmPlayer.trigger(this, "${r.label}: $quem", r.volume, n.contentIntent, pkg, telefone(n, titulo))
    }

    private fun soDigitos(s: String): String? {
        val d = s.filter { it.isDigit() }
        if (d.length < 10 || d.length > 15) return null
        return if (d.length <= 11) "55$d" else d // número sem código do país: assume Brasil
    }

    /** Tenta achar o telefone de quem mandou: lista de pessoas da notificação ou título que é só um número. */
    private fun telefone(n: Notification, titulo: String): String? {
        val e = n.extras
        try {
            e.getStringArray("android.people")?.forEach { u ->
                if (u.startsWith("tel:")) soDigitos(u.removePrefix("tel:"))?.let { return it }
            }
        } catch (_: Exception) {}
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                e.getParcelableArrayList<Person>("android.people.list")?.forEach { p ->
                    val u = p.uri
                    if (u != null && u.startsWith("tel:")) soDigitos(u.removePrefix("tel:"))?.let { return it }
                }
            }
        } catch (_: Exception) {}
        if (titulo.matches(Regex("^[+()\\d\\s-]{8,}$"))) return soDigitos(titulo)
        return null
    }
}
