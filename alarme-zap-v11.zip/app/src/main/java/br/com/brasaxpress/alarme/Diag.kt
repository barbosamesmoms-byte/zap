package br.com.brasaxpress.alarme

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Histórico das últimas decisões (aparece em Diagnóstico). Linhas iguais em sequência viram uma só. */
object Diag {
    private var ultimaMsg = ""
    private var ultimaHora = 0L

    @Synchronized
    fun add(ctx: Context, message: String) {
        val agora = System.currentTimeMillis()
        val hora = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(agora))
        val linha = "$hora · $message"
        val sp = ctx.getSharedPreferences("alarme_debug", Context.MODE_PRIVATE)
        if (message == ultimaMsg && agora - ultimaHora < 60_000L) {
            ultimaHora = agora
            sp.edit().putString("ultima", linha).apply()
            return
        }
        ultimaMsg = message
        ultimaHora = agora
        val linhas = (sp.getString("historico", "") ?: "").split("\n").filter { it.isNotBlank() }.toMutableList()
        linhas.add(linha)
        while (linhas.size > 15) linhas.removeAt(0)
        sp.edit().putString("ultima", linha).putString("historico", linhas.joinToString("\n")).apply()
    }
}
