package br.com.brasaxpress.alarme

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Vigia do serviço de notificações. De tempos em tempos o app manda uma notificação de teste para si
 * mesmo e confere se o Android a entregou ao WaListener. Se não entregou, o serviço está "morto"
 * (acontece em celulares Xiaomi): o vigia desliga e liga o serviço para forçar a reconexão e, se
 * continuar falhando dentro do horário das regras, avisa com som para você corrigir.
 */
object Watchdog {
    const val HB_ID = 77
    private const val ALERTA_ID = 3
    private const val CH_HB = "batimento"
    private const val CH_ALERTA = "alerta"

    private val handler = Handler(Looper.getMainLooper())
    private val iniciouEm = System.currentTimeMillis()

    /** O WaListener grava aqui o instante em que viu o teste. */
    @Volatile var ultimoBatimento = 0L

    private var verificando = false
    private var falhasSeguidas = 0
    private var ultimoAlerta = 0L

    private fun hora() = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())

    private fun estado(ctx: Context, ok: Boolean, texto: String) {
        ctx.getSharedPreferences("alarme_debug", Context.MODE_PRIVATE).edit()
            .putString("batimento", "${hora()} · $texto")
            .putBoolean("batimento_ok", ok)
            .apply()
    }

    /** Garante que o serviço de notificações não ficou desligado por uma troca interrompida. */
    fun garantirHabilitado(ctx: Context) {
        try {
            ctx.packageManager.setComponentEnabledSetting(
                ComponentName(ctx, WaListener::class.java),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP
            )
        } catch (_: Exception) {}
    }

    fun verificar(context: Context) {
        val ctx = context.applicationContext
        if (verificando) return
        // logo depois de abrir o app o Android ainda está conectando o serviço
        if (System.currentTimeMillis() - iniciouEm < 45_000L) return
        if (Store.rules(ctx).none { it.enabled }) return

        if (!NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)) {
            estado(ctx, false, "acesso às notificações está DESLIGADO")
            alertar(ctx, "Acesso às notificações desligado", "O alarme não vai tocar. Toque para ligar de novo.")
            return
        }

        verificando = true
        val enviado = System.currentTimeMillis()
        try {
            postarTeste(ctx)
        } catch (_: Exception) {
            verificando = false
            estado(ctx, true, "não consegui postar o teste")
            return
        }
        handler.postDelayed({ conferir(ctx, enviado) }, 15_000L)
    }

    private fun postarTeste(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_HB, "Teste de funcionamento", NotificationManager.IMPORTANCE_MIN).apply {
                setShowBadge(false)
            }
        )
        val n = NotificationCompat.Builder(ctx, CH_HB)
            .setSmallIcon(R.drawable.ic_stat_alarm)
            .setContentTitle("Verificando o Alarme Zap")
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setSilent(true)
            .setTimeoutAfter(20_000L)
            .build()
        nm.notify(HB_ID, n)
    }

    private fun conferir(ctx: Context, enviado: Long) {
        verificando = false
        try { ctx.getSystemService(NotificationManager::class.java).cancel(HB_ID) } catch (_: Exception) {}

        if (ultimoBatimento >= enviado) {
            if (falhasSeguidas > 0) Diag.add(ctx, "Serviço de notificações voltou a responder")
            falhasSeguidas = 0
            estado(ctx, true, "ok (o Android entregou o teste)")
            limparAlerta(ctx)
            return
        }

        falhasSeguidas++
        estado(ctx, false, "FALHOU ($falhasSeguidas): o Android não entregou o teste; reconectando")
        Diag.add(ctx, "Serviço de notificações não respondeu ao teste; reconectando")
        reiniciarListener(ctx)
        if (falhasSeguidas >= 2 && dentroOuPerto(ctx)) {
            alertar(ctx, "O Alarme Zap parou de ouvir o WhatsApp", "Toque para abrir o app e corrigir.")
        }
        if (falhasSeguidas < 3) handler.postDelayed({ verificar(ctx) }, 20_000L)
    }

    /** Desliga e liga o serviço para o Android reconectá-lo. */
    fun reiniciarListener(ctx: Context) {
        val cn = ComponentName(ctx, WaListener::class.java)
        val pm = ctx.packageManager
        try {
            pm.setComponentEnabledSetting(cn, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
            handler.postDelayed({
                garantirHabilitado(ctx)
                try { NotificationListenerService.requestRebind(cn) } catch (_: Exception) {}
            }, 1_000L)
        } catch (_: Exception) {
            garantirHabilitado(ctx)
        }
    }

    private fun dentroOuPerto(ctx: Context): Boolean {
        val agora = Calendar.getInstance()
        val daqui30 = Calendar.getInstance().apply { add(Calendar.MINUTE, 30) }
        return Store.rules(ctx).filter { it.enabled }.any { Rules.active(it, agora) || Rules.active(it, daqui30) }
    }

    private fun alertar(ctx: Context, titulo: String, texto: String) {
        val agora = System.currentTimeMillis()
        if (agora - ultimoAlerta < 10 * 60 * 1000L) return
        ultimoAlerta = agora
        try {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CH_ALERTA, "Alertas do Alarme Zap", NotificationManager.IMPORTANCE_HIGH)
            )
            val pi = PendingIntent.getActivity(
                ctx, 1, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(ctx, CH_ALERTA)
                .setSmallIcon(R.drawable.ic_stat_alarm)
                .setContentTitle(titulo)
                .setContentText(texto)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build()
            nm.notify(ALERTA_ID, n)
        } catch (_: Exception) {}
    }

    private fun limparAlerta(ctx: Context) {
        try { ctx.getSystemService(NotificationManager::class.java).cancel(ALERTA_ID) } catch (_: Exception) {}
    }

    /** Segundo vigia, independente do aviso fixo: o alarme do sistema acorda o app a cada ~5 min. */
    fun agendar(ctx: Context) {
        try {
            val am = ctx.getSystemService(AlarmManager::class.java)
            val pi = PendingIntent.getBroadcast(
                ctx, 7, Intent(ctx, WatchdogReceiver::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 5 * 60 * 1000L, pi)
        } catch (_: Exception) {}
    }
}

class WatchdogReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (!Store.monitorOn(c) || Store.rules(c).none { it.enabled }) return
        Watchdog.garantirHabilitado(c)
        MonitorService.start(c)
        Watchdog.verificar(c)
        Watchdog.agendar(c)
    }
}
