package br.com.brasaxpress.alarme

import android.app.Notification
import android.app.Person
import android.content.ComponentName
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class WaListener : NotificationListenerService() {
    companion object {
        /** true enquanto o Android mantém este serviço conectado. */
        @Volatile var conectado = false
        private var ultimaChave = ""
        private var ultimaHora = 0L
    }

    private fun diagnostic(message: String) {
        val stamp = SimpleDateFormat("dd/MM HH:mm:ss", Locale.getDefault()).format(Date())
        getSharedPreferences("alarme_debug", MODE_PRIVATE).edit()
            .putString("ultima", "$stamp · $message")
            .apply()
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        conectado = true
        getSharedPreferences("alarme_debug", MODE_PRIVATE).edit()
            .putString("listener", "conectado")
            .putString("ultima", "Acesso às notificações conectado ao Android")
            .apply()
    }

    override fun onListenerDisconnected() {
        getSharedPreferences("alarme_debug", MODE_PRIVATE).edit()
            .putString("listener", "desconectado")
            .putString("ultima", "O Android desconectou o acesso às notificações")
            .apply()
        conectado = false
        // Pede ao Android para reconectar sozinho
        try { requestRebind(ComponentName(this, WaListener::class.java)) } catch (_: Exception) {}
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val n = sbn.notification
        val e = n.extras
        val pkg = sbn.packageName

        // Marca que o Android continua entregando notificações (aparece no Diagnóstico)
        getSharedPreferences("alarme_debug", MODE_PRIVATE).edit()
            .putString("visto", SimpleDateFormat("dd/MM HH:mm:ss", Locale.getDefault()).format(Date()) + " · " + pkg)
            .apply()

        // Só registra diagnóstico de apps que têm regra (evita lixo de outros apps)
        val candidatas = Store.rules(this).filter { it.enabled && it.pkg == pkg }
        if (candidatas.isEmpty()) return

        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) {
            diagnostic("Ignorada: resumo de notificações de $pkg")
            return
        }
        if (n.category == Notification.CATEGORY_CALL) {
            diagnostic("Ignorada: chamada de $pkg")
            return
        }

        val titulo = e.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val texto = (e.getCharSequence(Notification.EXTRA_TEXT) ?: e.getCharSequence(Notification.EXTRA_BIG_TEXT))
            ?.toString().orEmpty()

        // "WhatsApp procurando novas mensagens" e similares não são mensagens
        if (Rules.isWhatsApp(pkg) && Rules.isSync(n, titulo, texto)) {
            diagnostic("Ignorada: aviso fixo/sincronização do WhatsApp (\"$titulo $texto\")")
            return
        }

        val isGroup = e.getBoolean("android.isGroupConversation", false) ||
            e.getCharSequence("android.conversationTitle") != null

        val agora = Calendar.getInstance()
        val r = candidatas
            .filter { Rules.active(it, agora) && Rules.typeOk(it, isGroup) }
            .maxByOrNull { it.volume }
        if (r == null) {
            diagnostic("Mensagem de $pkg fora do dia/horário ou do tipo da regra")
            return
        }

        // O WhatsApp às vezes reposta a mesma notificação; não toca de novo para a mesma mensagem
        val chave = "${sbn.key}|$texto"
        val agoraMs = System.currentTimeMillis()
        if (chave == ultimaChave && agoraMs - ultimaHora < 2 * 60 * 1000L) {
            diagnostic("Ignorada: mesma mensagem repetida pelo WhatsApp")
            return
        }
        ultimaChave = chave
        ultimaHora = agoraMs

        val quem = titulo.ifEmpty { r.label }
        diagnostic("Mensagem de $quem → tocando alarme")
        AlarmPlayer.trigger(this, "${r.label}: $quem", r.volume, n.contentIntent, pkg, telefone(n, titulo))
    }

    private fun soDigitos(s: String): String? {
        val d = s.filter { it.isDigit() }
        if (d.length < 10 || d.length > 15) return null
        return if (d.length <= 11) "55$d" else d // número sem código do país: assume Brasil
    }

    /** Tenta achar o telefone de quem mandou: lista de pessoas da notificação ou título que é só um número. */
    private fun telefone(n: Notification, titulo: String): String? {
        val e = n.extras
        try {
            e.getStringArray("android.people")?.forEach { u ->
                if (u.startsWith("tel:")) soDigitos(u.removePrefix("tel:"))?.let { return it }
            }
        } catch (_: Exception) {}
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                e.getParcelableArrayList<Person>("android.people.list")?.forEach { p ->
                    val u = p.uri
                    if (u != null && u.startsWith("tel:")) soDigitos(u.removePrefix("tel:"))?.let { return it }
                }
            }
        } catch (_: Exception) {}
        if (titulo.matches(Regex("^[+()\\d\\s-]{8,}$"))) return soDigitos(titulo)
        return null
    }
}
