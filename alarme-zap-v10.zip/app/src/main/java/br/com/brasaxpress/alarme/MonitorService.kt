package br.com.brasaxpress.alarme

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.service.notification.NotificationListenerService
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Mantém o app vivo (aviso fixo discreto) e, de tempos em tempos, confere se o Android ainda está
 * entregando as notificações; se o serviço foi desconectado, pede para reconectar.
 */
class MonitorService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val vigia = object : Runnable {
        override fun run() {
            if (!WaListener.conectado) {
                try {
                    NotificationListenerService.requestRebind(ComponentName(this@MonitorService, WaListener::class.java))
                } catch (_: Exception) {}
            }
            val hora = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            getSharedPreferences("alarme_debug", MODE_PRIVATE).edit()
                .putString("monitor", "ativo · conferido às $hora")
                .apply()
            handler.postDelayed(this, 5 * 60 * 1000L)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        val n = notificacao()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(ID, n)
        }
        handler.removeCallbacks(vigia)
        handler.post(vigia)
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(vigia)
        getSharedPreferences("alarme_debug", MODE_PRIVATE).edit().putString("monitor", "desligado").apply()
        super.onDestroy()
    }

    private fun notificacao(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("monitor", "Monitor do alarme", NotificationManager.IMPORTANCE_LOW).apply {
                setShowBadge(false)
            }
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, "monitor")
            .setSmallIcon(R.drawable.ic_stat_alarm)
            .setContentTitle("Alarme Zap ativo")
            .setContentText("Monitorando mensagens do WhatsApp")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(pi)
            .build()
    }

    companion object {
        const val ID = 2

        fun start(c: Context) {
            try {
                ContextCompat.startForegroundService(c, Intent(c, MonitorService::class.java))
            } catch (_: Exception) {}
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, MonitorService::class.java))
        }
    }
}
