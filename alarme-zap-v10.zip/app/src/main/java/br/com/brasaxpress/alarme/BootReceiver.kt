package br.com.brasaxpress.alarme

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Depois de ligar o celular ou atualizar o app, volta a monitorar. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Store.monitorOn(c) && Store.rules(c).any { it.enabled }) MonitorService.start(c)
    }
}
