# Alarme Zap v10 (1.7)

- Ignora o aviso fixo "WhatsApp procurando novas mensagens" e outras sincronizações: só mensagens de verdade tocam.
- Ícone novo (sino laranja com ponto verde) e tema escuro com laranja "brasa".
- Editor de regra em uma tela só (app, mensagens, dias, horário, volume); toque numa regra para editar.
- Tela do alarme nova, com "deslize para parar".

Publicação: envie o conteúdo desta pasta para o repositório (a pasta app inteira, incluindo app/src/main/res), confira o build verde em Actions e baixe o APK em Artifacts.
- Tela do alarme com duas barras: "Abrir conversa" (para o alarme e abre o chat) e "Parar alarme".
- "Abrir conversa": tenta o link direto pelo telefone, depois a notificação original, depois o app; o resultado aparece em Diagnóstico.
- Monitor permanente (aviso fixo discreto) que mantém o app vivo e reconecta o acesso às notificações se o Android desligar.
- Ao abrir o app com o alarme tocando, a tela de parar abre sozinha; botão "Parar alarme agora"; o som para sempre que o serviço do alarme termina.
- Chave de assinatura fixa: dá para instalar a versão nova por cima, sem desinstalar (a partir desta versão).
- Diagnóstico agora guarda as últimas 15 notificações com o motivo (tocou / ignorada e por quê); filtro de repetição reduzido para 20 s.
